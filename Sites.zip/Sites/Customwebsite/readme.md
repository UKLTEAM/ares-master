

           
             _____ _____________________ _________  
            /  _  \ _____   \_   _____//   _____/  
           /  /_\  \|       _/|    __)_ \_____  \   
          /    |    \    |   \|        \/        \  
          \____|__  /____|_  /_______  /_______  /  
                  \/       \/        \/        \/   
               by princeofguilty & deltax           


customize any website you want and link its action with "data.php"

data.php redirects to oauth.html, you can customize it if you want

Note Main webpage must be named "index.htm"
